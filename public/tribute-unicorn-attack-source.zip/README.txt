Tribute Unicorn Attack source

jam/src.js — full js13k game source
js13k-entry.zip — submit this (under 13KB)
src/game — deluxe preview TypeScript
